# Ideas para controlar

## Spotify
  - Giro en el eje X a la iquierda SkipToPrevious
  - Giro en el eje X a la derecha SkipToNext
  - Entrada desde telegram para guardar canción AddToMySaveTracks
  - play una pulsación del botón
  - pause dos pulsaciones del botón
  - (Si el botón se mantiene presionado es para mover el cubo)
  - GUARDAR TODAS LAS CANCIONES EN UNA COLECCIÓN DE MONGO DB
  - Recibir en Telegram la canción actualmente reproducida y dar la opción de guardarla

## Alexa (mostrando junto al dashboard) 
  - Giro en Y positivo subir un grado la temperatura (Tenemos un termostato)
  - Giro en Y negativo bajar un grado la temperatura (Tenemos un termostato)
  - GUARDAR TODAS TEMPERATURA, HUMEDAD Y PRESIÓN EN UNA COLECCIÓN DE MONGO DB
  - Recibir en Telegram si la temperatura y tal la cambiamos

  
  - Giro en Z positivo aumentar intensidad de la lámpara (4 tramos)
  - Giro en Z negativo apagar la lámpara 
  - Mostrar el estado de la lámpara en el dashboard
  - GUARDAR EL ESTADO DE LA LÁMPARA EN UNA COLECCIÓN DE MONGO DB
  - Recibir en Telegram si cambiamos la lámpara


  - Push hacia delante cambiar al siguiente canal de la tele
  - Push hacia atrás cambiar al anterior canal de la tele
  - Mostrar el canal de la tele en el dashboard
  - GUARDAR LOS CANALES EN UNA COLECCIÓN DE MONGO DB
  - Recibir en Telegram el canal de la tele en el que estamos
  

